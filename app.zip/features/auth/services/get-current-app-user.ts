"use server";

import { cookies } from "next/headers";

import { AppUserRole } from "@prisma/client";

import prisma from "@/lib/prisma";

console.log("[get-current-app-user.ts] Module loaded, prisma:", !!prisma, "type:", typeof prisma);

import {
  APP_ROLE_COOKIE,
  APP_USER_COOKIE,
  DEFAULT_APP_ROLE,
  isAppRole,
  type AppRole,
} from "../constants/roles";

const DEFAULT_APP_USERS: Record<
  AppUserRole,
  {
    name: string;
    emailPrefix: string;
  }
> = {
  ADMIN: {
    name: "Admin Operator",
    emailPrefix: "admin",
  },
  MANAGER: {
    name: "Manager Operator",
    emailPrefix: "manager",
  },
  STAFF: {
    name: "Staff Operator",
    emailPrefix: "staff",
  },
};

function toAppUserRole(role: AppRole) {
  return role as AppUserRole;
}

function getWorkspaceSuffix(
  clinicId?: string | null
) {
  return clinicId?.trim().toLowerCase() || "workspace";
}

export async function ensureDefaultAppUsers() {
  console.log("[ensureDefaultAppUsers] Starting, prisma:", !!prisma, "type:", typeof prisma);
  
  const clinic = await prisma.clinic.findFirst({
    select: {
      id: true,
    },
  });

  const workspaceSuffix =
    getWorkspaceSuffix(clinic?.id);

  await Promise.all(
    Object.entries(DEFAULT_APP_USERS).map(
      async ([role, defaults]) => {
        const email = `${defaults.emailPrefix}+${workspaceSuffix}@membership-core.local`;

        await prisma.appUser.upsert({
          where: {
            email,
          },
          update: {
            clinicId: clinic?.id ?? null,
            role:
              role as AppUserRole,
          },
          create: {
            clinicId: clinic?.id ?? null,
            name: defaults.name,
            email,
            role:
              role as AppUserRole,
          },
        });
      }
    )
  );

  return prisma.appUser.findMany({
    where: clinic
      ? {
          OR: [
            {
              clinicId: clinic.id,
            },
            {
              clinicId: null,
            },
          ],
        }
      : {
          clinicId: null,
        },
    orderBy: [
      {
        role: "asc",
      },
      {
        name: "asc",
      },
    ],
  });
}

export async function getAvailableAppUsers() {
  const users =
    await ensureDefaultAppUsers();

  return users.map((user) => ({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role as AppRole,
  }));
}

export async function getCurrentAppUser() {
  const cookieStore = await cookies();
  const users =
    await ensureDefaultAppUsers();
  const storedUserId =
    cookieStore.get(APP_USER_COOKIE)?.value;

  if (storedUserId) {
    const storedUser = users.find(
      (user) => user.id === storedUserId
    );

    if (storedUser) {
      return {
        id: storedUser.id,
        name: storedUser.name,
        email: storedUser.email,
        role:
          storedUser.role as AppRole,
      };
    }
  }

  const storedRole =
    cookieStore.get(APP_ROLE_COOKIE)?.value;
  const preferredRole =
    storedRole && isAppRole(storedRole)
      ? storedRole
      : DEFAULT_APP_ROLE;

  const fallbackUser =
    users.find(
      (user) =>
        user.role ===
        toAppUserRole(preferredRole)
    ) ?? users[0];

  if (!fallbackUser) {
    throw new Error(
      "Application users could not be initialized."
    );
  }

  return {
    id: fallbackUser.id,
    name: fallbackUser.name,
    email: fallbackUser.email,
    role:
      fallbackUser.role as AppRole,
  };
}
