import { getCurrentAppUser } from "./get-current-app-user";

export async function getCurrentUserRole() {
  const currentUser =
    await getCurrentAppUser();

  return currentUser.role;
}
