import type { AppRole } from "@/features/auth/constants/roles";

export const APP_RESOURCES = [
  "dashboard",
  "patients",
  "crm",
  "plans",
  "benefits",
  "subscriptions",
  "clinic",
  "benefitUsage",
  "auditLogs",
] as const;

export type AppResource =
  (typeof APP_RESOURCES)[number];

export type PermissionAction =
  | "view"
  | "manage";

const ROLE_PERMISSIONS: Record<
  AppRole,
  Record<
    AppResource,
    readonly PermissionAction[]
  >
> = {
  ADMIN: {
    dashboard: ["view", "manage"],
    patients: ["view", "manage"],
    crm: ["view", "manage"],
    plans: ["view", "manage"],
    benefits: ["view", "manage"],
    subscriptions: ["view", "manage"],
    clinic: ["view", "manage"],
    benefitUsage: ["view", "manage"],
    auditLogs: ["view"],
  },
  MANAGER: {
    dashboard: ["view"],
    patients: ["view", "manage"],
    crm: ["view", "manage"],
    plans: ["view", "manage"],
    benefits: ["view", "manage"],
    subscriptions: ["view", "manage"],
    clinic: ["view"],
    benefitUsage: ["view", "manage"],
    auditLogs: ["view"],
  },
  STAFF: {
    dashboard: ["view"],
    patients: ["view", "manage"],
    crm: ["view", "manage"],
    plans: ["view"],
    benefits: ["view"],
    subscriptions: ["view", "manage"],
    clinic: [],
    benefitUsage: ["view", "manage"],
    auditLogs: [],
  },
};

export const RESOURCE_LABELS: Record<
  AppResource,
  string
> = {
  dashboard: "Dashboard",
  patients: "Patients",
  crm: "CRM",
  plans: "Plans",
  benefits: "Benefits",
  subscriptions: "Subscriptions",
  clinic: "Clinic",
  benefitUsage: "Benefit Usage",
  auditLogs: "Audit Log",
};

export function hasPermission(
  role: AppRole,
  resource: AppResource,
  action: PermissionAction
) {
  return ROLE_PERMISSIONS[role][
    resource
  ].includes(action);
}
