import type { AppRole } from "@/features/auth/constants/roles";
import { getRoleLabel } from "@/features/auth/constants/roles";
import { RoleSwitcher } from "@/features/auth/components/role-switcher";

type Props = {
  role: AppRole;
  currentUser: {
    id: string;
    name: string;
    email: string;
  };
  users: Array<{
    id: string;
    name: string;
    email: string;
    role: AppRole;
  }>;
};

export function DashboardHeader({
  role,
  currentUser,
  users,
}: Props) {
  return (
    <header className="flex min-h-16 items-center justify-between border-b border-border/60 bg-background/95 px-4 md:px-6">
      <div>
        <h2 className="font-semibold tracking-tight">
          Operations
        </h2>

        <p className="text-sm text-muted-foreground">
          {getRoleLabel(role)} workspace
        </p>
      </div>

      <div className="flex items-center gap-4 text-sm text-muted-foreground">
        <div className="hidden text-right md:block">
          <div className="text-sm font-medium text-foreground">
            {currentUser.name}
          </div>
          <div className="text-xs text-muted-foreground">
            {currentUser.email}
          </div>
        </div>
        <RoleSwitcher
          currentUserId={currentUser.id}
          users={users}
        />
        <span>Membership Core SaaS</span>
      </div>
    </header>
  );
}
